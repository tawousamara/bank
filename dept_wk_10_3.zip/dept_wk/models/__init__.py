from . import configuration
from . import document_manager
from . import tables
from . import ocr_inherit
from . import nouvelle_table
from . import tcr_inherit
from . import tracking
from . import wizards
from . import configuration_risk
from . import option_risk
from . import scoring
from . import workflow_new
from . import etape
from . import analytics




