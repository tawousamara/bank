from . import folders
from . import tags
from . import res_partner
from . import ir_attachment
